import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { View, StyleSheet } from 'react-native';
import { AppProvider, useApp } from './src/context/AppContext';
import { Navbar } from './src/components/Navbar';
import { DashboardScreen } from './src/screens/DashboardScreen';
import { TransactionsScreen } from './src/screens/TransactionsScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';
import { TabType } from './src/types';

function MainApp() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      {activeTab === 'dashboard' && <DashboardScreen />}
      {activeTab === 'unassigned' && <DashboardScreen />}
      {activeTab === 'branches' && <DashboardScreen />}
      {activeTab === 'transactions' && <TransactionsScreen />}
      {activeTab === 'analytics' && <DashboardScreen />}
      {activeTab === 'settings' && <SettingsScreen />}
      <Navbar activeTab={activeTab} onChange={setActiveTab} />
    </View>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#020617' },
});
