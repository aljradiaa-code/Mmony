export interface Branch {
  id: string;
  name: string;
  location?: string;
  managerName?: string;
  phone?: string;
  totalToday: number;
  totalAllTime: number;
  transactionCountToday: number;
  color?: string;
}

export interface SMSTransaction {
  id: string;
  rawSmsText: string;
  senderId: string;
  providerName: string;
  transferRefNumber: string;
  amount: number;
  currency: string;
  senderCustomerName?: string;
  customerPhone?: string;
  timestamp: string;
  formattedDate: string;
  formattedTime: string;
  status: 'UNASSIGNED' | 'ASSIGNED';
  branchId?: string;
  branchName?: string;
  isSplit?: boolean;
  splits?: SplitAllocation[];
  assignedAt?: string;
  notes?: string;
  parsedMethod: 'REGEX' | 'AI';
  confidenceScore: number;
}

export interface SplitAllocation {
  branchId: string;
  branchName: string;
  amount: number;
}

export interface WalletProvider {
  id: string;
  name: string;
  displayName: string;
  senderIdPattern: string;
  color: string;
  parseRules: {
    amountRegex: string;
    refRegex: string;
    senderRegex: string;
    phoneRegex: string;
  };
  sampleMessages: string[];
}

export interface DailyCloseout {
  id: string;
  date: string;
  closedAt: string;
  totalWalletDeposits: number;
  totalAssignedToBranches: number;
  unassignedAmount: number;
  totalTransactionsCount: number;
  unassignedCount: number;
  branchBreakdown: BranchBreakdown[];
  closedBy: string;
  notes: string;
  status: 'RECONCILED' | 'NEEDS_AUDIT';
}

export interface BranchBreakdown {
  branchId: string;
  branchName: string;
  amount: number;
  count: number;
}

export interface ToastMessage {
  message: string;
  type?: 'success' | 'info' | 'error';
  undoTxId?: string;
  previousBranchId?: string;
}

export type TabType = 'dashboard' | 'unassigned' | 'branches' | 'transactions' | 'reconciliation' | 'analytics' | 'settings';
