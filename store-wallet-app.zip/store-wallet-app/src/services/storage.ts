import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  BRANCHES: 'store_wallet_branches',
  TRANSACTIONS: 'store_wallet_transactions',
  PROVIDERS: 'store_wallet_providers',
  CLOSEOUTS: 'store_wallet_closeouts',
  DEVICE_ID: 'store_wallet_device_id',
};

export const StorageKeys = KEYS;

export async function getItem<T>(key: string, defaultValue: T): Promise<T> {
  try { const v = await AsyncStorage.getItem(key); return v ? JSON.parse(v) : defaultValue; }
  catch { return defaultValue; }
}

export async function setItem<T>(key: string, value: T): Promise<void> {
  try { await AsyncStorage.setItem(key, JSON.stringify(value)); }
  catch (e) { console.error('Storage error:', e); }
}

export async function removeItem(key: string): Promise<void> {
  try { await AsyncStorage.removeItem(key); }
  catch (e) { console.error('Storage remove error:', e); }
}
