import { SMSTransaction } from '../types';

const API_BASE = 'https://your-backend-api.com/api';

export async function sendSmsToBackend(deviceId: string, sender: string, message: string, timestamp: string) {
  try {
    const res = await fetch(`${API_BASE}/sms`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deviceId, sender, message, timestamp }),
    });
    return await res.json();
  } catch (e) { console.error('API Error:', e); return { success: false }; }
}

export async function fetchTransactions(deviceId: string): Promise<SMSTransaction[]> {
  try {
    const res = await fetch(`${API_BASE}/transactions?deviceId=${deviceId}`);
    const data = await res.json();
    return data.transactions || [];
  } catch (e) { console.error('Fetch Error:', e); return []; }
}
