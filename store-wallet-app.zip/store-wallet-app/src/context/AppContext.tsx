import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { Branch, SMSTransaction, WalletProvider, DailyCloseout, ToastMessage } from '../types';
import { INITIAL_BRANCHES, INITIAL_TRANSACTIONS, DEFAULT_WALLET_PROVIDERS } from '../data/initialData';
import { StorageKeys, getItem, setItem } from '../services/storage';
import { parseSmsText, formatDate, formatTime, generateId } from '../utils/smsParser';

interface AppState {
  branches: Branch[]; transactions: SMSTransaction[]; providers: WalletProvider[];
  closeouts: DailyCloseout[]; toast: ToastMessage | null; isLoading: boolean;
}

type Action =
  | { type: 'SET_BRANCHES'; payload: Branch[] } | { type: 'SET_TRANSACTIONS'; payload: SMSTransaction[] }
  | { type: 'SET_PROVIDERS'; payload: WalletProvider[] } | { type: 'SET_CLOSEOUTS'; payload: DailyCloseout[] }
  | { type: 'SHOW_TOAST'; payload: ToastMessage } | { type: 'HIDE_TOAST' }
  | { type: 'SET_LOADING'; payload: boolean } | { type: 'ADD_TRANSACTION'; payload: SMSTransaction }
  | { type: 'UPDATE_TRANSACTION'; payload: SMSTransaction } | { type: 'DELETE_TRANSACTION'; payload: string }
  | { type: 'ADD_BRANCH'; payload: Branch } | { type: 'UPDATE_BRANCH'; payload: Branch }
  | { type: 'ADD_CLOSEOUT'; payload: DailyCloseout } | { type: 'RESET_DATA' };

const init: AppState = { branches: INITIAL_BRANCHES, transactions: INITIAL_TRANSACTIONS, providers: DEFAULT_WALLET_PROVIDERS, closeouts: [], toast: null, isLoading: false };

function reducer(s: AppState, a: Action): AppState {
  switch (a.type) {
    case 'SET_BRANCHES': return { ...s, branches: a.payload };
    case 'SET_TRANSACTIONS': return { ...s, transactions: a.payload };
    case 'SET_PROVIDERS': return { ...s, providers: a.payload };
    case 'SET_CLOSEOUTS': return { ...s, closeouts: a.payload };
    case 'SHOW_TOAST': return { ...s, toast: a.payload };
    case 'HIDE_TOAST': return { ...s, toast: null };
    case 'SET_LOADING': return { ...s, isLoading: a.payload };
    case 'ADD_TRANSACTION': return { ...s, transactions: [a.payload, ...s.transactions] };
    case 'UPDATE_TRANSACTION': return { ...s, transactions: s.transactions.map(t => t.id === a.payload.id ? a.payload : t) };
    case 'DELETE_TRANSACTION': return { ...s, transactions: s.transactions.filter(t => t.id !== a.payload) };
    case 'ADD_BRANCH': return { ...s, branches: [...s.branches, a.payload] };
    case 'UPDATE_BRANCH': return { ...s, branches: s.branches.map(b => b.id === a.payload.id ? a.payload : b) };
    case 'ADD_CLOSEOUT': return { ...s, closeouts: [a.payload, ...s.closeouts] };
    case 'RESET_DATA': return { ...init };
    default: return s;
  }
}

interface CtxType {
  state: AppState; dispatch: React.Dispatch<Action>;
  addTransaction: (rawSms: string, senderId: string, branchId?: string) => void;
  assignTransaction: (txId: string, branchId: string, notes?: string) => void;
  splitTransaction: (txId: string, splits: any[], notes?: string) => void;
  deleteTransaction: (txId: string) => void;
  addBranch: (b: Omit<Branch, 'id'|'totalToday'|'totalAllTime'|'transactionCountToday'>) => void;
  updateBranch: (b: Branch) => void;
  executeCloseout: (notes: string) => void;
  showToast: (msg: string, type?: 'success'|'info'|'error') => void;
  resetData: () => void;
  exportCSV: () => void;
}

const AppContext = createContext<CtxType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, init);

  useEffect(() => {
    (async () => {
      dispatch({ type: 'SET_LOADING', payload: true });
      const b = await getItem<Branch[]>(StorageKeys.BRANCHES, INITIAL_BRANCHES);
      const t = await getItem<SMSTransaction[]>(StorageKeys.TRANSACTIONS, INITIAL_TRANSACTIONS);
      const p = await getItem<WalletProvider[]>(StorageKeys.PROVIDERS, DEFAULT_WALLET_PROVIDERS);
      const c = await getItem<DailyCloseout[]>(StorageKeys.CLOSEOUTS, []);
      dispatch({ type: 'SET_BRANCHES', payload: b });
      dispatch({ type: 'SET_TRANSACTIONS', payload: t });
      dispatch({ type: 'SET_PROVIDERS', payload: p });
      dispatch({ type: 'SET_CLOSEOUTS', payload: c });
      dispatch({ type: 'SET_LOADING', payload: false });
    })();
  }, []);

  useEffect(() => { setItem(StorageKeys.BRANCHES, state.branches); }, [state.branches]);
  useEffect(() => { setItem(StorageKeys.TRANSACTIONS, state.transactions); }, [state.transactions]);
  useEffect(() => { setItem(StorageKeys.PROVIDERS, state.providers); }, [state.providers]);
  useEffect(() => { setItem(StorageKeys.CLOSEOUTS, state.closeouts); }, [state.closeouts]);

  useEffect(() => {
    const updated = state.branches.map(b => {
      let totalToday = 0, countToday = 0;
      state.transactions.forEach(t => {
        if (t.status === 'ASSIGNED') {
          if (t.isSplit && t.splits) { const a = t.splits.find(s => s.branchId === b.id); if (a) { totalToday += a.amount; countToday++; } }
          else if (t.branchId === b.id) { totalToday += t.amount; countToday++; }
        }
      });
      return { ...b, totalToday, transactionCountToday: countToday };
    });
    if (JSON.stringify(updated) !== JSON.stringify(state.branches)) dispatch({ type: 'SET_BRANCHES', payload: updated });
  }, [state.transactions]);

  const showToast = (msg: string, type: 'success'|'info'|'error' = 'success') => {
    dispatch({ type: 'SHOW_TOAST', payload: { message: msg, type } });
    setTimeout(() => dispatch({ type: 'HIDE_TOAST' }), 4000);
  };

  const addTransaction = (rawSms: string, senderId: string, branchId?: string) => {
    const parsed = parseSmsText(rawSms, senderId);
    const d = new Date();
    const branchObj = state.branches.find(b => b.id === branchId);
    const newTx: SMSTransaction = {
      id: generateId('tx'), rawSmsText: rawSms, senderId, providerName: parsed.providerName || 'محفظة غير معروفة',
      transferRefNumber: parsed.transferRefNumber || generateId('TXN'), amount: parsed.amount || 0, currency: 'YER',
      senderCustomerName: parsed.senderCustomerName, customerPhone: parsed.customerPhone,
      timestamp: d.toISOString(), formattedDate: formatDate(d), formattedTime: formatTime(d),
      status: branchId ? 'ASSIGNED' : 'UNASSIGNED', branchId: branchId || undefined, branchName: branchObj?.name,
      assignedAt: branchId ? d.toISOString() : undefined, parsedMethod: 'REGEX', confidenceScore: parsed.confidenceScore || 50,
    };
    dispatch({ type: 'ADD_TRANSACTION', payload: newTx });
    showToast(branchId && branchObj ? `تمت إضافة وتقييد الحوالة لفرع ${branchObj.name}` : 'تمت إضافة الحوالة إلى صندوق المعلق', branchId ? 'success' : 'info');
  };

  const assignTransaction = (txId: string, branchId: string, notes?: string) => {
    const tx = state.transactions.find(t => t.id === txId); if (!tx) return;
    const branchObj = state.branches.find(b => b.id === branchId);
    const updated: SMSTransaction = { ...tx, status: branchId ? 'ASSIGNED' : 'UNASSIGNED', branchId: branchId || undefined, branchName: branchObj?.name, isSplit: false, splits: undefined, assignedAt: branchId ? new Date().toISOString() : undefined, notes: notes !== undefined ? notes : tx.notes };
    dispatch({ type: 'UPDATE_TRANSACTION', payload: updated });
    if (branchId && branchObj) showToast(`تم تقييد الحوالة #${tx.transferRefNumber} لفرع ${branchObj.name}`, 'success');
  };

  const splitTransaction = (txId: string, splits: any[], notes?: string) => {
    const tx = state.transactions.find(t => t.id === txId); if (!tx) return;
    const updated: SMSTransaction = { ...tx, status: 'ASSIGNED', branchId: undefined, branchName: undefined, isSplit: true, splits, assignedAt: new Date().toISOString(), notes: notes !== undefined ? notes : tx.notes };
    dispatch({ type: 'UPDATE_TRANSACTION', payload: updated });
    showToast(`تم تجزئة الحوالة بين (${splits.map(s => s.branchName).join(' و ')})`, 'success');
  };

  const deleteTransaction = (txId: string) => { dispatch({ type: 'DELETE_TRANSACTION', payload: txId }); showToast('تم حذف الحوالة من السجل', 'info'); };

  const addBranch = (branchData: Omit<Branch, 'id'|'totalToday'|'totalAllTime'|'transactionCountToday'>) => {
    const newBranch: Branch = { ...branchData, id: generateId('branch'), totalToday: 0, totalAllTime: 0, transactionCountToday: 0 };
    dispatch({ type: 'ADD_BRANCH', payload: newBranch });
    showToast(`تمت إضافة فرع "${newBranch.name}"`, 'success');
  };

  const updateBranch = (branch: Branch) => { dispatch({ type: 'UPDATE_BRANCH', payload: branch }); showToast(`تم تحديث بيانات فرع "${branch.name}"`, 'success'); };

  const executeCloseout = (notes: string) => {
    const dateStr = new Date().toISOString().split('T')[0];
    const unassigned = state.transactions.filter(t => t.status === 'UNASSIGNED');
    const totalAmount = state.transactions.reduce((sum, t) => sum + t.amount, 0);
    const assignedAmount = state.transactions.filter(t => t.status === 'ASSIGNED').reduce((sum, t) => sum + t.amount, 0);
    const closeout: DailyCloseout = {
      id: generateId('closeout'), date: dateStr, closedAt: new Date().toISOString(),
      totalWalletDeposits: totalAmount, totalAssignedToBranches: assignedAmount,
      unassignedAmount: unassigned.reduce((sum, t) => sum + t.amount, 0),
      totalTransactionsCount: state.transactions.length, unassignedCount: unassigned.length,
      branchBreakdown: state.branches.map(b => { const bTxs = state.transactions.filter(t => t.branchId === b.id); return { branchId: b.id, branchName: b.name, amount: bTxs.reduce((sum, t) => sum + t.amount, 0), count: bTxs.length }; }),
      closedBy: 'المدير العام', notes, status: unassigned.length === 0 ? 'RECONCILED' : 'NEEDS_AUDIT',
    };
    dispatch({ type: 'ADD_CLOSEOUT', payload: closeout });
    showToast('تم إغلاق اليومية بنجاح', 'success');
  };

  const resetData = () => { dispatch({ type: 'RESET_DATA' }); showToast('تمت إعادة ضبط البيانات', 'info'); };

  const exportCSV = () => {
    const headers = ['رقم الحوالة', 'المحفظة', 'المبلغ', 'اسم المحول', 'الفرع المقيد له', 'التاريخ', 'الوقت', 'الحالة'];
    const rows = state.transactions.map(t => [t.transferRefNumber, t.providerName, String(t.amount), t.senderCustomerName || 'عام', t.branchName || 'غير مقيد', t.formattedDate, t.formattedTime, t.status === 'ASSIGNED' ? 'مقيدة' : 'معلقة']);
    const csv = '﻿' + [headers.join(','), ...rows.map(r => r.join(','))].join('
');
    console.log('CSV:', csv.substring(0, 200) + '...');
    showToast('تم تصدير CSV', 'success');
  };

  return (
    <AppContext.Provider value={{ state, dispatch, addTransaction, assignTransaction, splitTransaction, deleteTransaction, addBranch, updateBranch, executeCloseout, showToast, resetData, exportCSV }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const c = useContext(AppContext);
  if (!c) throw new Error('useApp must be used within AppProvider');
  return c;
}
