import { SMSTransaction, WalletProvider } from '../types';
import { DEFAULT_WALLET_PROVIDERS } from '../data/initialData';

export { DEFAULT_WALLET_PROVIDERS };

export function detectProvider(senderId: string): WalletProvider | null {
  const normalizedSender = senderId.toLowerCase();
  for (const provider of DEFAULT_WALLET_PROVIDERS) {
    const patterns = provider.senderIdPattern.split('|');
    for (const pattern of patterns) {
      if (normalizedSender.includes(pattern.toLowerCase().trim())) return provider;
    }
  }
  return null;
}

export function parseSmsText(rawSms: string, senderId: string): Partial<SMSTransaction> {
  const provider = detectProvider(senderId);
  let amount = 0, transferRefNumber = '', senderCustomerName = '', customerPhone = '';
  let providerName = provider?.displayName || 'محفظة غير معروفة';
  let confidenceScore = 50;

  if (provider) {
    const amountMatch = rawSms.match(new RegExp(provider.parseRules.amountRegex, 'i'));
    if (amountMatch) { amount = parseInt(amountMatch[1].replace(/,/g, ''), 10) || 0; confidenceScore += 20; }
    const refMatch = rawSms.match(new RegExp(provider.parseRules.refRegex, 'i'));
    if (refMatch) { transferRefNumber = refMatch[1]; confidenceScore += 15; }
    const senderMatch = rawSms.match(new RegExp(provider.parseRules.senderRegex, 'i'));
    if (senderMatch) { senderCustomerName = senderMatch[1].trim(); confidenceScore += 10; }
    const phoneMatch = rawSms.match(new RegExp(provider.parseRules.phoneRegex, 'i'));
    if (phoneMatch) { customerPhone = phoneMatch[1]; confidenceScore += 5; }
  }

  if (amount === 0) {
    const generalAmountMatch = rawSms.match(/([0-9,]+)\s*(?:ر\.ي|ريال|YER|ريال يمني)/i);
    if (generalAmountMatch) amount = parseInt(generalAmountMatch[1].replace(/,/g, ''), 10) || 0;
  }
  if (!transferRefNumber) {
    const generalRefMatch = rawSms.match(/([A-Z]{2,4}-\d{6,10})/);
    if (generalRefMatch) transferRefNumber = generalRefMatch[1];
    else transferRefNumber = 'TXN-' + Math.floor(Math.random() * 100000000);
  }

  return { providerName, transferRefNumber, amount, currency: 'YER', senderCustomerName: senderCustomerName || undefined, customerPhone: customerPhone || undefined, parsedMethod: 'REGEX', confidenceScore: Math.min(confidenceScore, 100) };
}

export function formatCurrency(amount: number, currency: string = 'YER'): string {
  return currency === 'YER' ? `${amount.toLocaleString('ar-YE')} ر.ي` : `${amount.toLocaleString('ar-YE')} ${currency}`;
}

export function formatDate(date: Date): string {
  return date.toLocaleDateString('ar-YE', { year: 'numeric', month: '2-digit', day: '2-digit' });
}

export function formatTime(date: Date): string {
  return date.toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit', hour12: true });
}

export function generateId(prefix: string = 'id'): string {
  return `${prefix}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}
