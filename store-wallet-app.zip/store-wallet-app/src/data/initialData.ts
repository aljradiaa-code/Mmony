import { Branch, SMSTransaction, WalletProvider } from '../types';

export const INITIAL_BRANCHES: Branch[] = [
  { id: 'branch-1', name: 'الفرع الرئيسي - صنعاء', location: 'شارع الستين، صنعاء', managerName: 'أحمد علي', phone: '777123456', totalToday: 0, totalAllTime: 125000, transactionCountToday: 0, color: '#10b981' },
  { id: 'branch-2', name: 'فرع الحديدة', location: 'شارع صنعاء، الحديدة', managerName: 'محمد صالح', phone: '777234567', totalToday: 0, totalAllTime: 89000, transactionCountToday: 0, color: '#3b82f6' },
  { id: 'branch-3', name: 'فرع تعز', location: 'جولة المصباحي، تعز', managerName: 'خالد عبدالله', phone: '777345678', totalToday: 0, totalAllTime: 67000, transactionCountToday: 0, color: '#f59e0b' },
  { id: 'branch-4', name: 'فرع عدن', location: 'خورمكسر، عدن', managerName: 'سعيد حسن', phone: '777456789', totalToday: 0, totalAllTime: 54000, transactionCountToday: 0, color: '#ef4444' },
];

export const INITIAL_TRANSACTIONS: SMSTransaction[] = [
  {
    id: 'tx-demo-1', rawSmsText: 'تم استلام حوالة بمبلغ 50000 ر.ي من أحمد محمد. رقم الحوالة: TXN-12345678. شكراً لاستخدامكم جوالي.',
    senderId: 'Jawali', providerName: 'جوالي', transferRefNumber: 'TXN-12345678', amount: 50000, currency: 'YER',
    senderCustomerName: 'أحمد محمد', customerPhone: '777111222',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    formattedDate: new Date(Date.now() - 3600000).toLocaleDateString('ar-YE'),
    formattedTime: new Date(Date.now() - 3600000).toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' }),
    status: 'UNASSIGNED', parsedMethod: 'REGEX', confidenceScore: 95,
  },
  {
    id: 'tx-demo-2', rawSmsText: 'استلمت حوالة مالية بقيمة 25000 ر.ي من فاطمة علي. رقم العملية: REF-87654321. Shamil Money.',
    senderId: 'Shamil', providerName: 'شامل موني', transferRefNumber: 'REF-87654321', amount: 25000, currency: 'YER',
    senderCustomerName: 'فاطمة علي', customerPhone: '777333444',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    formattedDate: new Date(Date.now() - 7200000).toLocaleDateString('ar-YE'),
    formattedTime: new Date(Date.now() - 7200000).toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' }),
    status: 'UNASSIGNED', parsedMethod: 'REGEX', confidenceScore: 92,
  },
  {
    id: 'tx-demo-3', rawSmsText: 'تم إيداع مبلغ 100000 ر.ي في محفظتك. المرسل: شركة التجارة اليمنية. رقم: DEP-11223344. كاش.',
    senderId: 'Cash-e', providerName: 'كاش', transferRefNumber: 'DEP-11223344', amount: 100000, currency: 'YER',
    senderCustomerName: 'شركة التجارة اليمنية', customerPhone: '700555666',
    timestamp: new Date(Date.now() - 10800000).toISOString(),
    formattedDate: new Date(Date.now() - 10800000).toLocaleDateString('ar-YE'),
    formattedTime: new Date(Date.now() - 10800000).toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' }),
    status: 'ASSIGNED', branchId: 'branch-1', branchName: 'الفرع الرئيسي - صنعاء',
    assignedAt: new Date(Date.now() - 10800000).toISOString(), parsedMethod: 'REGEX', confidenceScore: 88,
  },
];

export const DEFAULT_WALLET_PROVIDERS: WalletProvider[] = [
  { id: 'provider-jawali', name: 'Jawali', displayName: 'جوالي (Jawali / WeCash)', senderIdPattern: 'Jawali|WeCash|جوالي|Yemen Mobile|يمن موبايل', color: '#e11d48',
    parseRules: { amountRegex: '(?:مبلغ|قيمة|amount|value)\s*(?:ب)?\s*([0-9,]+)', refRegex: '(?:رقم الحوالة|رقم العملية|رقم|ref|reference)\s*:?\s*([A-Z0-9-]+)', senderRegex: '(?:من|from|المرسل)\s*:?\s*([\u0600-\u06FF\s]+)', phoneRegex: '(?:هاتف|phone|رقم)\s*:?\s*(\d{9,})' },
    sampleMessages: ['تم استلام حوالة بمبلغ 50000 ر.ي من أحمد محمد. رقم الحوالة: TXN-12345678.'] },
  { id: 'provider-shamil', name: 'Shamil', displayName: 'شامل موني (Shamil Money)', senderIdPattern: 'Shamil|ShamilMoney|شامل|شامل موني|SBYB', color: '#2563eb',
    parseRules: { amountRegex: '(?:مبلغ|قيمة|amount)\s*(?:ب)?\s*([0-9,]+)', refRegex: '(?:رقم العملية|رقم|ref)\s*:?\s*([A-Z0-9-]+)', senderRegex: '(?:من|from|المرسل)\s*:?\s*([\u0600-\u06FF\s]+)', phoneRegex: '(?:هاتف|phone|رقم)\s*:?\s*(\d{9,})' },
    sampleMessages: ['استلمت حوالة مالية بقيمة 25000 ر.ي من فاطمة علي. رقم العملية: REF-87654321.'] },
  { id: 'provider-cashe', name: 'Cash-e', displayName: 'كاش (Cash-e)', senderIdPattern: 'Cash|Cash-e|كاش|Tamkeen|تمكين', color: '#059669',
    parseRules: { amountRegex: '(?:مبلغ|قيمة|amount|value)\s*(?:ب)?\s*([0-9,]+)', refRegex: '(?:رقم|ref|reference)\s*:?\s*([A-Z0-9-]+)', senderRegex: '(?:من|from|المرسل)\s*:?\s*([\u0600-\u06FF\s]+)', phoneRegex: '(?:هاتف|phone|رقم)\s*:?\s*(\d{9,})' },
    sampleMessages: ['تم إيداع مبلغ 100000 ر.ي في محفظتك. المرسل: شركة التجارة اليمنية. رقم: DEP-11223344.'] },
  { id: 'provider-cac', name: 'CAC', displayName: 'كاك بنك (CAC Bank)', senderIdPattern: 'CAC|CACBank|كاك|كاك بنك', color: '#7c3aed',
    parseRules: { amountRegex: '(?:مبلغ|قيمة|amount)\s*(?:ب)?\s*([0-9,]+)', refRegex: '(?:رقم|ref|reference)\s*:?\s*([A-Z0-9-]+)', senderRegex: '(?:من|from|المرسل)\s*:?\s*([\u0600-\u06FF\s]+)', phoneRegex: '(?:هاتف|phone|رقم)\s*:?\s*(\d{9,})' },
    sampleMessages: ['تم استلام حوالة بمبلغ 75000 ر.ي من خالد عبدالرحمن. رقم الحوالة: CAC-99887766.'] },
  { id: 'provider-ykb', name: 'YKB', displayName: 'بنك اليمن والكويت (YKB)', senderIdPattern: 'YKB|YemenKuwait|اليمن والكويت|Yemen Kuwait', color: '#ea580c',
    parseRules: { amountRegex: '(?:مبلغ|قيمة|amount)\s*(?:ب)?\s*([0-9,]+)', refRegex: '(?:رقم|ref|reference)\s*:?\s*([A-Z0-9-]+)', senderRegex: '(?:من|from|المرسل)\s*:?\s*([\u0600-\u06FF\s]+)', phoneRegex: '(?:هاتف|phone|رقم)\s*:?\s*(\d{9,})' },
    sampleMessages: ['تم استلام حوالة بمبلغ 30000 ر.ي من سعيد حسن. رقم الحوالة: YKB-55443322.'] },
  { id: 'provider-iby', name: 'IBY', displayName: 'البنك الدولي (IBY)', senderIdPattern: 'IBY|InternationalBank|الدولي|International Bank of Yemen', color: '#0891b2',
    parseRules: { amountRegex: '(?:مبلغ|قيمة|amount)\s*(?:ب)?\s*([0-9,]+)', refRegex: '(?:رقم|ref|reference)\s*:?\s*([A-Z0-9-]+)', senderRegex: '(?:من|from|المرسل)\s*:?\s*([\u0600-\u06FF\s]+)', phoneRegex: '(?:هاتف|phone|رقم)\s*:?\s*(\d{9,})' },
    sampleMessages: ['تم استلام حوالة بمبلغ 45000 ر.ي من محمد أحمد. رقم الحوالة: IBY-11223344.'] },
];
