import React, { useState } from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet, TextInput, ScrollView } from 'react-native';
import { X, Send } from 'lucide-react-native';
import { Branch } from '../types';

export function AddSmsModal({ visible, onClose, branches, onAdd }: { visible: boolean; onClose: () => void; branches: Branch[]; onAdd: (rawSms: string, senderId: string, branchId?: string) => void; }) {
  const [rawSms, setRawSms] = useState('');
  const [senderId, setSenderId] = useState('Jawali');
  const [selectedBranch, setSelectedBranch] = useState<string | undefined>();

  const handleSubmit = () => { if (!rawSms.trim()) return; onAdd(rawSms.trim(), senderId, selectedBranch); setRawSms(''); setSelectedBranch(undefined); onClose(); };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <ScrollView contentContainerStyle={styles.scroll}>
          <View style={styles.modal}>
            <View style={styles.header}><Text style={styles.title}>📩 إضافة حوالة يدوياً</Text><TouchableOpacity onPress={onClose}><X size={24} color="#94a3b8" /></TouchableOpacity></View>
            <Text style={styles.label}>نص الرسالة (SMS)</Text>
            <TextInput style={styles.textArea} placeholder="الصق نص الرسالة هنا..." placeholderTextColor="#64748b" value={rawSms} onChangeText={setRawSms} multiline numberOfLines={4} textAlign="right" textAlignVertical="top" />
            <Text style={styles.label}>اسم المرسل / المحفظة</Text>
            <TextInput style={styles.input} placeholder="مثال: Jawali, Shamil, كاش" placeholderTextColor="#64748b" value={senderId} onChangeText={setSenderId} textAlign="right" />
            <Text style={styles.label}>تقييد مباشر لفرع (اختياري)</Text>
            <View style={styles.branchesRow}>
              <TouchableOpacity onPress={() => setSelectedBranch(undefined)} style={[styles.branchChip, !selectedBranch && styles.selectedChip]}><Text style={!selectedBranch ? styles.selectedChipText : styles.chipText}>بدون تقييد</Text></TouchableOpacity>
              {branches.map(b => (
                <TouchableOpacity key={b.id} onPress={() => setSelectedBranch(b.id)} style={[styles.branchChip, selectedBranch === b.id && { backgroundColor: b.color + '25', borderColor: b.color }]}>
                  <Text style={selectedBranch === b.id ? { color: b.color, fontWeight: 'bold', fontSize: 12 } : styles.chipText}>{b.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity onPress={handleSubmit} style={styles.submitBtn}><Send size={18} color="#fff" /><Text style={styles.submitText}>إضافة الحوالة</Text></TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.85)', justifyContent: 'center' },
  scroll: { flexGrow: 1, justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: '#0f172a', borderRadius: 16, padding: 20, borderWidth: 1, borderColor: '#334155' },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  title: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  label: { color: '#94a3b8', fontSize: 12, marginBottom: 6, marginTop: 12, textAlign: 'right' },
  textArea: { backgroundColor: '#1e293b', color: '#fff', borderRadius: 10, padding: 12, borderWidth: 1, borderColor: '#334155', minHeight: 100, fontSize: 14, textAlignVertical: 'top' },
  input: { backgroundColor: '#1e293b', color: '#fff', borderRadius: 10, padding: 12, borderWidth: 1, borderColor: '#334155', fontSize: 14 },
  branchesRow: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 6 },
  branchChip: { backgroundColor: '#1e293b', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 8, borderWidth: 1, borderColor: '#334155' },
  selectedChip: { backgroundColor: '#10b98120', borderColor: '#10b981' },
  chipText: { color: '#94a3b8', fontSize: 12 },
  selectedChipText: { color: '#10b981', fontWeight: 'bold', fontSize: 12 },
  submitBtn: { backgroundColor: '#10b981', flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', padding: 14, borderRadius: 10, marginTop: 20, gap: 8 },
  submitText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
