import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { LayoutDashboard, Bell, Building2, FileText, BarChart3, Settings } from 'lucide-react-native';
import { TabType } from '../types';

const tabs: { key: TabType; label: string; icon: any }[] = [
  { key: 'dashboard', label: 'الرئيسية', icon: LayoutDashboard },
  { key: 'unassigned', label: 'المعلق', icon: Bell },
  { key: 'branches', label: 'الفروع', icon: Building2 },
  { key: 'transactions', label: 'الحوالات', icon: FileText },
  { key: 'analytics', label: 'التحليلات', icon: BarChart3 },
  { key: 'settings', label: 'الإعدادات', icon: Settings },
];

export function Navbar({ activeTab, onChange }: { activeTab: TabType; onChange: (t: TabType) => void }) {
  return (
    <View style={styles.container}>
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.key;
        return (
          <TouchableOpacity key={tab.key} onPress={() => onChange(tab.key)} style={[styles.tab, isActive && styles.activeTab]}>
            <Icon size={20} color={isActive ? '#10b981' : '#64748b'} />
            <Text style={[styles.label, isActive && styles.activeLabel]}>{tab.label}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row-reverse', backgroundColor: '#0f172a', borderTopWidth: 1, borderTopColor: '#1e293b', paddingVertical: 6, paddingBottom: 24, position: 'absolute', bottom: 0, left: 0, right: 0 },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 4 },
  activeTab: { borderTopWidth: 2, borderTopColor: '#10b981' },
  label: { color: '#64748b', fontSize: 10, marginTop: 2 },
  activeLabel: { color: '#10b981', fontWeight: 'bold' },
});
