import React, { useState } from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet, TextInput, ScrollView } from 'react-native';
import { X, CheckCircle2 } from 'lucide-react-native';
import { SMSTransaction, Branch, SplitAllocation } from '../types';
import { formatCurrency } from '../utils/smsParser';

export function SplitTransactionModal({ transaction, branches, visible, onClose, onConfirm }: { transaction: SMSTransaction | null; branches: Branch[]; visible: boolean; onClose: () => void; onConfirm: (txId: string, splits: SplitAllocation[], notes?: string) => void; }) {
  const [allocations, setAllocations] = useState<{ branchId: string; amount: string }[]>([]);
  const [notes, setNotes] = useState('');
  if (!transaction) return null;
  const totalAllocated = allocations.reduce((sum, a) => sum + (parseFloat(a.amount) || 0), 0);
  const remaining = transaction.amount - totalAllocated;

  const toggleBranch = (branchId: string) => {
    const exists = allocations.find(a => a.branchId === branchId);
    if (exists) setAllocations(allocations.filter(a => a.branchId !== branchId));
    else setAllocations([...allocations, { branchId, amount: '' }]);
  };
  const updateAmount = (branchId: string, amount: string) => setAllocations(allocations.map(a => a.branchId === branchId ? { ...a, amount } : a));

  const handleConfirm = () => {
    const splits: SplitAllocation[] = allocations.filter(a => parseFloat(a.amount) > 0).map(a => {
      const branch = branches.find(b => b.id === a.branchId)!;
      return { branchId: a.branchId, branchName: branch.name, amount: parseFloat(a.amount) };
    });
    if (splits.length < 2 || remaining !== 0) return;
    onConfirm(transaction.id, splits, notes);
    setAllocations([]); setNotes(''); onClose();
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <ScrollView contentContainerStyle={styles.scroll}>
          <View style={styles.modal}>
            <View style={styles.header}><Text style={styles.title}>✂️ تجزئة الحوالة</Text><TouchableOpacity onPress={onClose}><X size={24} color="#94a3b8" /></TouchableOpacity></View>
            <Text style={styles.amount}>المبلغ الكلي: {formatCurrency(transaction.amount)}</Text>
            <Text style={[styles.remaining, remaining === 0 ? styles.remainingOk : styles.remainingWarn]}>المتبقي: {formatCurrency(remaining)}</Text>
            {branches.map(branch => {
              const alloc = allocations.find(a => a.branchId === branch.id);
              return (
                <TouchableOpacity key={branch.id} onPress={() => toggleBranch(branch.id)} style={styles.branchRow}>
                  <View style={[styles.checkbox, alloc && { backgroundColor: branch.color, borderColor: branch.color }]}>{alloc && <CheckCircle2 size={14} color="#fff" />}</View>
                  <Text style={styles.branchName}>{branch.name}</Text>
                  {alloc && <TextInput style={styles.amountInput} placeholder="المبلغ" placeholderTextColor="#64748b" keyboardType="numeric" value={alloc.amount} onChangeText={(t) => updateAmount(branch.id, t)} textAlign="center" />}
                </TouchableOpacity>
              );
            })}
            <TextInput style={styles.notesInput} placeholder="ملاحظات (اختياري)" placeholderTextColor="#64748b" value={notes} onChangeText={setNotes} textAlign="right" multiline />
            <TouchableOpacity onPress={handleConfirm} disabled={remaining !== 0 || allocations.length < 2} style={[styles.confirmBtn, (remaining !== 0 || allocations.length < 2) && styles.disabledBtn]}>
              <Text style={styles.confirmText}>تأكيد التجزئة</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.85)', justifyContent: 'center' },
  scroll: { flexGrow: 1, justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: '#0f172a', borderRadius: 16, padding: 20, borderWidth: 1, borderColor: '#334155' },
  header: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  title: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  amount: { color: '#10b981', fontSize: 16, fontWeight: 'bold', textAlign: 'center', marginBottom: 4 },
  remaining: { fontSize: 14, textAlign: 'center', marginBottom: 16, fontWeight: 'bold' },
  remainingOk: { color: '#10b981' },
  remainingWarn: { color: '#f59e0b' },
  branchRow: { flexDirection: 'row-reverse', alignItems: 'center', padding: 12, backgroundColor: '#1e293b', borderRadius: 10, marginBottom: 8, gap: 10 },
  checkbox: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: '#64748b', alignItems: 'center', justifyContent: 'center' },
  branchName: { color: '#fff', flex: 1, textAlign: 'right', fontSize: 14 },
  amountInput: { backgroundColor: '#0f172a', color: '#fff', borderRadius: 6, paddingHorizontal: 10, paddingVertical: 5, width: 90, borderWidth: 1, borderColor: '#334155', fontSize: 14 },
  notesInput: { backgroundColor: '#1e293b', color: '#fff', borderRadius: 8, padding: 12, marginTop: 8, marginBottom: 16, borderWidth: 1, borderColor: '#334155', minHeight: 60, fontSize: 14, textAlignVertical: 'top' },
  confirmBtn: { backgroundColor: '#10b981', padding: 14, borderRadius: 10, alignItems: 'center' },
  disabledBtn: { backgroundColor: '#334155' },
  confirmText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
