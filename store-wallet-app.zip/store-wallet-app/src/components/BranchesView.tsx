import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Modal, TextInput } from 'react-native';
import { Plus, Edit3 } from 'lucide-react-native';
import { Branch } from '../types';
import { formatCurrency } from '../utils/smsParser';

export function BranchesView({ branches, onAdd, onEdit }: { branches: Branch[]; onAdd: (b: any) => void; onEdit: (b: Branch) => void; }) {
  const [modalVisible, setModalVisible] = useState(false);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editingBranch, setEditingBranch] = useState<Branch | null>(null);
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [manager, setManager] = useState('');

  const openAdd = () => { setName(''); setLocation(''); setManager(''); setModalVisible(true); };
  const openEdit = (branch: Branch) => { setEditingBranch(branch); setName(branch.name); setLocation(branch.location || ''); setManager(branch.managerName || ''); setEditModalVisible(true); };
  const handleAdd = () => { if (!name.trim()) return; onAdd({ name: name.trim(), location: location.trim(), managerName: manager.trim(), phone: '' }); setModalVisible(false); };
  const handleEdit = () => { if (!editingBranch || !name.trim()) return; onEdit({ ...editingBranch, name: name.trim(), location: location.trim(), managerName: manager.trim() }); setEditModalVisible(false); };

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text style={styles.header}>🏢 الفروع ({branches.length})</Text>
        <TouchableOpacity onPress={openAdd} style={styles.addBtn}><Plus size={20} color="#fff" /></TouchableOpacity>
      </View>
      <FlatList data={branches} keyExtractor={(item) => item.id} scrollEnabled={false}
        renderItem={({ item }) => (
          <View style={[styles.card, { borderRightColor: item.color || '#10b981', borderRightWidth: 4 }]}>
            <View style={styles.cardTop}>
              <View style={{ flex: 1 }}><Text style={styles.name}>{item.name}</Text><Text style={styles.meta}>{item.location || '—'} • {item.managerName || '—'}</Text></View>
              <TouchableOpacity onPress={() => openEdit(item)} style={styles.editBtn}><Edit3 size={16} color="#64748b" /></TouchableOpacity>
            </View>
            <View style={styles.stats}>
              <View style={styles.stat}><Text style={styles.statValue}>{formatCurrency(item.totalToday)}</Text><Text style={styles.statLabel}>إجمالي اليوم</Text></View>
              <View style={styles.stat}><Text style={styles.statValue}>{item.transactionCountToday}</Text><Text style={styles.statLabel}>عدد الحوالات</Text></View>
              <View style={styles.stat}><Text style={styles.statValue}>{formatCurrency(item.totalAllTime)}</Text><Text style={styles.statLabel}>الإجمالي الكلي</Text></View>
            </View>
          </View>
        )}
      />
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>➕ إضافة فرع جديد</Text>
            <TextInput style={styles.input} placeholder="اسم الفرع" placeholderTextColor="#64748b" value={name} onChangeText={setName} textAlign="right" />
            <TextInput style={styles.input} placeholder="الموقع" placeholderTextColor="#64748b" value={location} onChangeText={setLocation} textAlign="right" />
            <TextInput style={styles.input} placeholder="اسم المدير" placeholderTextColor="#64748b" value={manager} onChangeText={setManager} textAlign="right" />
            <View style={styles.modalActions}>
              <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.cancelBtn}><Text style={styles.cancelText}>إلغاء</Text></TouchableOpacity>
              <TouchableOpacity onPress={handleAdd} style={styles.saveBtn}><Text style={styles.saveText}>حفظ</Text></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      <Modal visible={editModalVisible} transparent animationType="slide">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>✏️ تعديل الفرع</Text>
            <TextInput style={styles.input} placeholder="اسم الفرع" placeholderTextColor="#64748b" value={name} onChangeText={setName} textAlign="right" />
            <TextInput style={styles.input} placeholder="الموقع" placeholderTextColor="#64748b" value={location} onChangeText={setLocation} textAlign="right" />
            <TextInput style={styles.input} placeholder="اسم المدير" placeholderTextColor="#64748b" value={manager} onChangeText={setManager} textAlign="right" />
            <View style={styles.modalActions}>
              <TouchableOpacity onPress={() => setEditModalVisible(false)} style={styles.cancelBtn}><Text style={styles.cancelText}>إلغاء</Text></TouchableOpacity>
              <TouchableOpacity onPress={handleEdit} style={styles.saveBtn}><Text style={styles.saveText}>تحديث</Text></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerRow: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  header: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  addBtn: { backgroundColor: '#10b981', width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  card: { backgroundColor: '#1e293b', borderRadius: 12, padding: 14, marginBottom: 10 },
  cardTop: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginBottom: 10 },
  name: { color: '#fff', fontSize: 15, fontWeight: 'bold', textAlign: 'right' },
  meta: { color: '#64748b', fontSize: 12, textAlign: 'right', marginTop: 4 },
  editBtn: { padding: 4 },
  stats: { flexDirection: 'row-reverse', gap: 16 },
  stat: { alignItems: 'center', flex: 1 },
  statValue: { color: '#10b981', fontSize: 14, fontWeight: 'bold' },
  statLabel: { color: '#64748b', fontSize: 10, marginTop: 2 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', padding: 24 },
  modal: { backgroundColor: '#0f172a', borderRadius: 16, padding: 20, borderWidth: 1, borderColor: '#334155' },
  modalTitle: { color: '#fff', fontSize: 17, fontWeight: 'bold', textAlign: 'center', marginBottom: 16 },
  input: { backgroundColor: '#1e293b', color: '#fff', borderRadius: 8, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: '#334155', fontSize: 14 },
  modalActions: { flexDirection: 'row-reverse', gap: 10, marginTop: 8 },
  cancelBtn: { flex: 1, backgroundColor: '#334155', padding: 12, borderRadius: 8, alignItems: 'center' },
  cancelText: { color: '#cbd5e1', fontWeight: 'bold' },
  saveBtn: { flex: 1, backgroundColor: '#10b981', padding: 12, borderRadius: 8, alignItems: 'center' },
  saveText: { color: '#fff', fontWeight: 'bold' },
});
