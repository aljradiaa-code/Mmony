import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { CheckCircle2, Layers, Bell } from 'lucide-react-native';
import { SMSTransaction, Branch } from '../types';
import { formatCurrency } from '../utils/smsParser';

export function UnassignedFeed({ transactions, branches, onAssign, onSplit }: { transactions: SMSTransaction[]; branches: Branch[]; onAssign: (txId: string, branchId: string) => void; onSplit: (tx: SMSTransaction) => void; }) {
  if (transactions.length === 0) return (
    <View style={styles.empty}><Bell size={48} color="#334155" /><Text style={styles.emptyText}>لا توجد حوالات معلقة</Text><Text style={styles.emptySub}>جميع الحوالات مقيدة ✅</Text></View>
  );
  return (
    <View style={styles.container}>
      <Text style={styles.header}>📥 صندوق الحوالات المعلقة ({transactions.length})</Text>
      <FlatList data={transactions} keyExtractor={(item) => item.id} scrollEnabled={false}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <View style={styles.providerBadge}><Text style={styles.providerText}>{item.providerName}</Text></View>
              <Text style={styles.amount}>{formatCurrency(item.amount)}</Text>
            </View>
            <Text style={styles.ref}>رقم الحوالة: #{item.transferRefNumber}</Text>
            {item.senderCustomerName && <Text style={styles.sender}>👤 {item.senderCustomerName}</Text>}
            {item.customerPhone && <Text style={styles.phone}>📞 {item.customerPhone}</Text>}
            <Text style={styles.date}>{item.formattedDate} • {item.formattedTime}</Text>
            <View style={styles.actions}>
              <TouchableOpacity onPress={() => onSplit(item)} style={styles.splitBtn}><Layers size={14} color="#f59e0b" /><Text style={styles.splitText}>تجزئة</Text></TouchableOpacity>
              {branches.map((branch) => (
                <TouchableOpacity key={branch.id} onPress={() => onAssign(item.id, branch.id)} style={[styles.assignBtn, { borderColor: branch.color }]}>
                  <CheckCircle2 size={14} color={branch.color} /><Text style={[styles.assignText, { color: branch.color }]}>{branch.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 16 },
  header: { color: '#fff', fontSize: 16, fontWeight: 'bold', marginBottom: 12, textAlign: 'right' },
  empty: { alignItems: 'center', paddingVertical: 40 },
  emptyText: { color: '#64748b', fontSize: 16, marginTop: 12 },
  emptySub: { color: '#334155', fontSize: 13, marginTop: 4 },
  card: { backgroundColor: '#1e293b', borderRadius: 12, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: '#334155' },
  cardHeader: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  providerBadge: { backgroundColor: '#0f172a', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6 },
  providerText: { color: '#94a3b8', fontSize: 12, fontWeight: 'bold' },
  amount: { color: '#10b981', fontSize: 18, fontWeight: 'bold' },
  ref: { color: '#64748b', fontSize: 12, textAlign: 'right', marginBottom: 4 },
  sender: { color: '#cbd5e1', fontSize: 13, textAlign: 'right', marginBottom: 2 },
  phone: { color: '#64748b', fontSize: 12, textAlign: 'right', marginBottom: 4 },
  date: { color: '#475569', fontSize: 11, textAlign: 'right', marginBottom: 10 },
  actions: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 6, marginTop: 4 },
  splitBtn: { flexDirection: 'row-reverse', alignItems: 'center', backgroundColor: '#451a03', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, gap: 4 },
  splitText: { color: '#f59e0b', fontSize: 11, fontWeight: 'bold' },
  assignBtn: { flexDirection: 'row-reverse', alignItems: 'center', backgroundColor: '#0f172a', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, gap: 4, borderWidth: 1 },
  assignText: { fontSize: 11, fontWeight: 'bold' },
});
