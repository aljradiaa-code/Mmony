import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { Trash2 } from 'lucide-react-native';
import { SMSTransaction, Branch } from '../types';
import { formatCurrency } from '../utils/smsParser';

export function TransactionsTable({ transactions, branches, onAssign, onDelete }: { transactions: SMSTransaction[]; branches: Branch[]; onAssign: (txId: string, branchId: string) => void; onDelete: (txId: string) => void; }) {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>📋 جميع الحوالات ({transactions.length})</Text>
      <FlatList data={transactions} keyExtractor={(item) => item.id} renderItem={({ item }) => (
        <View style={[styles.row, item.status === 'ASSIGNED' && styles.assignedRow]}>
          <View style={styles.rowTop}>
            <View><Text style={styles.amount}>{formatCurrency(item.amount)}</Text><Text style={styles.provider}>{item.providerName}</Text></View>
            <View style={[styles.badge, item.status === 'ASSIGNED' ? styles.assignedBadge : styles.unassignedBadge]}>
              <Text style={styles.badgeText}>{item.status === 'ASSIGNED' ? '✓ مقيدة' : '⏳ معلقة'}</Text>
            </View>
          </View>
          <Text style={styles.ref}>#{item.transferRefNumber} • {item.formattedDate}</Text>
          {item.status === 'UNASSIGNED' && (
            <View style={styles.assignRow}>
              {branches.map(b => (
                <TouchableOpacity key={b.id} onPress={() => onAssign(item.id, b.id)} style={[styles.assignChip, { backgroundColor: b.color + '25' }]}>
                  <Text style={[styles.assignChipText, { color: b.color }]}>{b.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
          {item.status === 'ASSIGNED' && item.branchName && <Text style={styles.branchName}>🏢 مقيدة لـ: {item.branchName}</Text>}
          <TouchableOpacity onPress={() => onDelete(item.id)} style={styles.deleteBtn}><Trash2 size={14} color="#ef4444" /><Text style={styles.deleteText}>حذف</Text></TouchableOpacity>
        </View>
      )} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  header: { color: '#fff', fontSize: 16, fontWeight: 'bold', marginBottom: 12, textAlign: 'right' },
  row: { backgroundColor: '#1e293b', borderRadius: 12, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: '#334155' },
  assignedRow: { borderColor: '#10b98140' },
  rowTop: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginBottom: 8, alignItems: 'center' },
  amount: { color: '#10b981', fontSize: 17, fontWeight: 'bold' },
  provider: { color: '#94a3b8', fontSize: 12, marginTop: 2 },
  badge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  assignedBadge: { backgroundColor: '#064e3b' },
  unassignedBadge: { backgroundColor: '#451a03' },
  badgeText: { fontSize: 11, fontWeight: 'bold', color: '#fff' },
  ref: { color: '#64748b', fontSize: 11, textAlign: 'right', marginBottom: 8 },
  assignRow: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 6, marginTop: 6 },
  assignChip: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 6 },
  assignChipText: { fontSize: 11, fontWeight: 'bold' },
  branchName: { color: '#10b981', fontSize: 12, textAlign: 'right', marginTop: 6, fontWeight: 'bold' },
  deleteBtn: { flexDirection: 'row-reverse', alignItems: 'center', alignSelf: 'flex-start', marginTop: 10, gap: 4 },
  deleteText: { color: '#ef4444', fontSize: 12 },
});
