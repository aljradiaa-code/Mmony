import React from 'react';
import { View, StyleSheet } from 'react-native';
import { useApp } from '../context/AppContext';
import { TransactionsTable } from '../components/TransactionsTable';

export function TransactionsScreen() {
  const { state, assignTransaction, deleteTransaction } = useApp();
  return (
    <View style={styles.container}>
      <TransactionsTable transactions={state.transactions} branches={state.branches} onAssign={(txId, branchId) => assignTransaction(txId, branchId)} onDelete={deleteTransaction} />
    </View>
  );
}
const styles = StyleSheet.create({ container: { flex: 1, backgroundColor: '#020617' } });
