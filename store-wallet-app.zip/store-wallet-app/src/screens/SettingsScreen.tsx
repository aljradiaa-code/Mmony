import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { Trash2, FileText, Info } from 'lucide-react-native';
import { useApp } from '../context/AppContext';

export function SettingsScreen() {
  const { resetData, exportCSV } = useApp();
  const handleReset = () => {
    Alert.alert('⚠️ إعادة الضبط', 'هل أنت متأكد من حذف جميع البيانات؟ لا يمكن التراجع!', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'نعم، احذف الكل', style: 'destructive', onPress: resetData }
    ]);
  };
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.header}>⚙️ الإعدادات</Text>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>📊 البيانات</Text>
        <TouchableOpacity onPress={exportCSV} style={styles.row}><FileText size={20} color="#3b82f6" /><Text style={styles.rowText}>تصدير كشف CSV</Text></TouchableOpacity>
        <TouchableOpacity onPress={handleReset} style={styles.row}><Trash2 size={20} color="#ef4444" /><Text style={[styles.rowText, { color: '#ef4444' }]}>إعادة ضبط جميع البيانات</Text></TouchableOpacity>
      </View>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>📱 iOS Shortcuts</Text>
        <View style={styles.infoBox}>
          <Info size={20} color="#f59e0b" />
          <View style={{ flex: 1 }}>
            <Text style={styles.infoTitle}>كيفية استقبال SMS تلقائياً</Text>
            <Text style={styles.infoDesc}>1. افتح Shortcuts على iPhone{'
'}2. اذهب إلى Automation{'
'}3. أنشئ Personal Automation{'
'}4. اختر Message وحدد اسم المحفظة{'
'}5. أضف Get Contents of URL (POST){'
'}6. أرسل لـ Backend API</Text>
          </View>
        </View>
      </View>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>ℹ️ عن التطبيق</Text>
        <View style={styles.infoRow}><Info size={20} color="#64748b" /><View><Text style={styles.infoTitle}>Store Wallet v1.0.0</Text><Text style={styles.infoDesc}>نظام إدارة حوالات المحافظ الإلكترونية</Text></View></View>
        <Text style={styles.note}>يدعم المحافظ: جوالي، شامل موني، كاش، كاك بنك، بنك اليمن والكويت، البنك الدولي</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#020617' },
  content: { padding: 16, paddingBottom: 100 },
  header: { color: '#fff', fontSize: 24, fontWeight: 'bold', marginBottom: 24, textAlign: 'right' },
  card: { backgroundColor: '#0f172a', borderRadius: 12, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#1e293b' },
  cardTitle: { color: '#94a3b8', fontSize: 12, fontWeight: 'bold', marginBottom: 12, textAlign: 'right' },
  row: { flexDirection: 'row-reverse', alignItems: 'center', paddingVertical: 12, gap: 12, borderBottomWidth: 1, borderBottomColor: '#1e293b' },
  rowText: { color: '#fff', fontSize: 15, flex: 1, textAlign: 'right' },
  infoBox: { flexDirection: 'row-reverse', gap: 12, backgroundColor: '#1e293b', padding: 14, borderRadius: 10 },
  infoRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12, marginBottom: 12 },
  infoTitle: { color: '#fff', fontSize: 15, fontWeight: 'bold', textAlign: 'right' },
  infoDesc: { color: '#94a3b8', fontSize: 13, textAlign: 'right', marginTop: 4, lineHeight: 22 },
  note: { color: '#475569', fontSize: 12, textAlign: 'right', marginTop: 12, lineHeight: 20 },
});
