import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { PlusCircle, TrendingUp, AlertCircle, Building2 } from 'lucide-react-native';
import { useApp } from '../context/AppContext';
import { UnassignedFeed } from '../components/UnassignedFeed';
import { BranchesView } from '../components/BranchesView';
import { AddSmsModal } from '../components/AddSmsModal';
import { SplitTransactionModal } from '../components/SplitTransactionModal';
import { SMSTransaction } from '../types';

export function DashboardScreen() {
  const { state, assignTransaction, splitTransaction, addTransaction, addBranch, updateBranch } = useApp();
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [splitTx, setSplitTx] = useState<SMSTransaction | null>(null);

  const unassigned = state.transactions.filter(t => t.status === 'UNASSIGNED');
  const totalToday = state.branches.reduce((sum, b) => sum + b.totalToday, 0);
  const totalCount = state.branches.reduce((sum, b) => sum + b.transactionCountToday, 0);

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.appHeader}>
          <Text style={styles.appTitle}>💰 محفظة المتجر</Text>
          <Text style={styles.appSubtitle}>نظام إدارة حوالات المحافظ</Text>
        </View>

        <View style={styles.statsRow}>
          <View style={[styles.statCard, { backgroundColor: '#10b98115', borderColor: '#10b98130' }]}>
            <TrendingUp size={22} color="#10b981" />
            <Text style={[styles.statValue, { color: '#10b981' }]}>{totalToday.toLocaleString('ar-YE')}</Text>
            <Text style={styles.statLabel}>إجمالي اليوم (ر.ي)</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#f59e0b15', borderColor: '#f59e0b30' }]}>
            <AlertCircle size={22} color="#f59e0b" />
            <Text style={[styles.statValue, { color: '#f59e0b' }]}>{unassigned.length}</Text>
            <Text style={styles.statLabel}>حوالات معلقة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#3b82f615', borderColor: '#3b82f630' }]}>
            <Building2 size={22} color="#3b82f6" />
            <Text style={[styles.statValue, { color: '#3b82f6' }]}>{totalCount}</Text>
            <Text style={styles.statLabel}>عدد الحوالات</Text>
          </View>
        </View>

        <TouchableOpacity onPress={() => setAddModalVisible(true)} style={styles.quickAdd}>
          <PlusCircle size={20} color="#fff" />
          <Text style={styles.quickAddText}>إضافة حوالة جديدة</Text>
        </TouchableOpacity>

        <UnassignedFeed transactions={unassigned} branches={state.branches} onAssign={(txId, branchId) => assignTransaction(txId, branchId)} onSplit={(tx) => setSplitTx(tx)} />

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🏢 الفروع</Text>
          <BranchesView branches={state.branches} onAdd={addBranch} onEdit={updateBranch} />
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      <AddSmsModal visible={addModalVisible} onClose={() => setAddModalVisible(false)} branches={state.branches} onAdd={addTransaction} />
      <SplitTransactionModal transaction={splitTx} branches={state.branches} visible={!!splitTx} onClose={() => setSplitTx(null)} onConfirm={splitTransaction} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#020617' },
  scroll: { flex: 1 },
  content: { padding: 16, paddingBottom: 120 },
  appHeader: { marginBottom: 20, alignItems: 'flex-end' },
  appTitle: { color: '#fff', fontSize: 24, fontWeight: 'bold' },
  appSubtitle: { color: '#64748b', fontSize: 13, marginTop: 2 },
  statsRow: { flexDirection: 'row-reverse', gap: 10, marginBottom: 16 },
  statCard: { flex: 1, borderRadius: 12, padding: 14, alignItems: 'center', borderWidth: 1 },
  statValue: { fontSize: 16, fontWeight: 'bold', marginTop: 8 },
  statLabel: { color: '#64748b', fontSize: 10, marginTop: 4 },
  quickAdd: { backgroundColor: '#10b981', flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', padding: 14, borderRadius: 12, marginBottom: 16, gap: 8, shadowColor: '#10b981', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4 },
  quickAddText: { color: '#fff', fontWeight: 'bold', fontSize: 15 },
  section: { marginTop: 8 },
  sectionTitle: { color: '#fff', fontSize: 16, fontWeight: 'bold', marginBottom: 12, textAlign: 'right' },
});
