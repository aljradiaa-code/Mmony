const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

exports.receiveSms = functions.https.onRequest(async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'POST');
  res.set('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).send('');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { deviceId, sender, message, timestamp } = req.body;
  if (!deviceId || !message) return res.status(400).json({ error: 'Missing required fields' });

  try {
    const parsed = parseYemeniSms(message, sender);
    const transaction = {
      id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      rawSmsText: message, senderId: sender || 'Unknown',
      providerName: parsed.providerName || 'محفظة غير معروفة',
      transferRefNumber: parsed.transferRefNumber || `TXN-${Math.floor(Math.random() * 10000000)}`,
      amount: parsed.amount || 0, currency: 'YER',
      senderCustomerName: parsed.senderCustomerName || null,
      customerPhone: parsed.customerPhone || null,
      timestamp: timestamp || new Date().toISOString(),
      status: 'UNASSIGNED', deviceId,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    };
    await db.collection('transactions').doc(transaction.id).set(transaction);

    try {
      const userDoc = await db.collection('users').doc(deviceId).get();
      const pushToken = userDoc.data()?.pushToken;
      if (pushToken) {
        await admin.messaging().send({
          token: pushToken,
          notification: { title: '💰 حوالة جديدة وصلت!', body: `مبلغ ${transaction.amount.toLocaleString()} ر.ي من ${transaction.providerName}` },
          data: { transactionId: transaction.id, amount: String(transaction.amount), provider: transaction.providerName },
          android: { priority: 'high' },
          apns: { payload: { aps: { sound: 'default', badge: 1 } } },
        });
      }
    } catch (e) { console.error('Push error:', e); }

    return res.status(200).json({ success: true, transaction });
  } catch (error) {
    console.error('Server error:', error);
    return res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});

exports.getTransactions = functions.https.onRequest(async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  const { deviceId } = req.query;
  if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });
  try {
    const snapshot = await db.collection('transactions').where('deviceId', '==', deviceId).orderBy('createdAt', 'desc').limit(500).get();
    return res.json({ transactions: snapshot.docs.map(d => ({ id: d.id, ...d.data() })), count: snapshot.size });
  } catch (e) { return res.status(500).json({ error: e.message }); }
});

exports.assignTransaction = functions.https.onRequest(async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const id = req.path.split('/').pop();
  const { branchId, branchName } = req.body;
  await db.collection('transactions').doc(id).update({ status: 'ASSIGNED', branchId, branchName, assignedAt: new Date().toISOString() });
  return res.json({ success: true });
});

exports.registerDevice = functions.https.onRequest(async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  const { deviceId, pushToken, platform } = req.body;
  if (!deviceId || !pushToken) return res.status(400).json({ error: 'Missing fields' });
  await db.collection('users').doc(deviceId).set({ pushToken, platform: platform || 'ios', updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  return res.json({ success: true });
});

function parseYemeniSms(message, sender) {
  const providers = [
    { name: 'جوالي (Jawali)', patterns: ['Jawali', 'WeCash', 'جوالي', 'Yemen Mobile', 'يمن موبايل'] },
    { name: 'شامل موني (Shamil)', patterns: ['Shamil', 'ShamilMoney', 'شامل', 'شامل موني', 'SBYB'] },
    { name: 'كاش (Cash-e)', patterns: ['Cash', 'Cash-e', 'كاش', 'Tamkeen', 'تمكين'] },
    { name: 'كاك بنك (CAC)', patterns: ['CAC', 'CACBank', 'كاك', 'كاك بنك'] },
    { name: 'بنك اليمن والكويت (YKB)', patterns: ['YKB', 'YemenKuwait', 'اليمن والكويت'] },
    { name: 'البنك الدولي (IBY)', patterns: ['IBY', 'InternationalBank', 'الدولي'] },
  ];
  let providerName = 'محفظة غير معروفة';
  const msgLower = message.toLowerCase(), senderLower = (sender || '').toLowerCase();
  for (const p of providers) {
    for (const pat of p.patterns) {
      if (msgLower.includes(pat.toLowerCase()) || senderLower.includes(pat.toLowerCase())) { providerName = p.name; break; }
    }
    if (providerName !== 'محفظة غير معروفة') break;
  }
  let amount = 0;
  const amountPatterns = [
    /(?:مبلغ|قيمة|amount|value)\s*(?:ب)?\s*([0-9,]+)/i,
    /([0-9,]+)\s*(?:ر\.ي|ريال|YER|ريال يمني)/i,
    /(?:received|استلمت|تم استلام)\s*(?:مبلغ)?\s*([0-9,]+)/i,
  ];
  for (const pat of amountPatterns) {
    const m = message.match(pat);
    if (m) { amount = parseInt(m[1].replace(/,/g, ''), 10) || 0; break; }
  }
  let transferRefNumber;
  const refPatterns = [
    /(?:رقم الحوالة|رقم العملية|رقم|ref|reference)\s*:?\s*([A-Z0-9-]{6,20})/i,
    /([A-Z]{2,4}-\d{6,10})/, /(\d{8,12})/,
  ];
  for (const pat of refPatterns) {
    const m = message.match(pat);
    if (m) { transferRefNumber = m[1]; break; }
  }
  let senderCustomerName;
  const senderPatterns = [
    /(?:من|from|المرسل|sender)\s*:?\s*([\u0600-\u06FF\s]{3,30})/i,
    /(?:من|from)\s+([\u0600-\u06FF\s]{3,30})/i,
  ];
  for (const pat of senderPatterns) {
    const m = message.match(pat);
    if (m) { senderCustomerName = m[1].trim(); break; }
  }
  let customerPhone;
  const phoneMatch = message.match(/(?:هاتف|phone|رقم|tel)\s*:?\s*(\d{7,10})/i);
  if (phoneMatch) customerPhone = phoneMatch[1];
  return { providerName, amount, transferRefNumber, senderCustomerName, customerPhone };
}
