# 💰 Store Wallet - محفظة المتجر

نظام إدارة حوالات المحافظ الإلكترونية للفروع التجارية في اليمن.

## ✨ الميزات

- 📩 استقبال وتحليل SMS من مزودي المحافظ تلقائياً
- 🏢 إدارة الفروع التجارية وتقييد الحوالات
- ✂️ تجزئة الحوالات بين فروع متعددة
- 📊 إحصائيات وتحليلات يومية
- 📤 تصدير CSV
- 🔔 Push Notifications
- 💾 حفظ البيانات محلياً (Offline support)

## 🏦 المحافظ المدعومة

| المحفظة | الاسم بالإنجليزي | اللون |
|---------|-----------------|-------|
| جوالي (Jawali / WeCash) | Jawali | 🔴 أحمر |
| شامل موني (Shamil Money) | Shamil Money | 🔵 أزرق |
| كاش (Cash-e) | Cash-e | 🟢 أخضر |
| كاك بنك (CAC Bank) | CAC Bank | 🟣 بنفسجي |
| بنك اليمن والكويت (YKB) | YKB | 🟠 برتقالي |
| البنك الدولي (IBY) | IBY | 🩵 سماوي |

## 🚀 التشغيل السريع

### 1. تثبيت التبعيات
```bash
npm install
```

### 2. تشغيل على المحاكي
```bash
npx expo start
```

### 3. بناء iOS
```bash
eas build --platform ios --profile production
```

## 🔧 إعداد Firebase Backend

### 1. إنشاء مشروع Firebase
1. اذهب إلى [Firebase Console](https://console.firebase.google.com)
2. أنشئ مشروع جديد
3. فعّل Firestore Database
4. فعّل Cloud Messaging

### 2. تثبيت Firebase CLI
```bash
npm install -g firebase-tools
firebase login
firebase init functions
```

### 3. نشر Cloud Functions
```bash
cd backend/firebase-functions
npm install
firebase deploy --only functions
```

### 4. تحديث إعدادات التطبيق
عدّل `src/services/firebase.ts` بمفاتيح مشروعك:
```typescript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  // ...
};
```

### 5. إعداد iOS Shortcuts
اتبع دليل `ios-shortcuts/SETUP_GUIDE.md`

## 🏗️ بناء عبر Codemagic

### 1. رفع على GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/store-wallet.git
git push -u origin main
```

### 2. إعداد Codemagic
1. سجل في [Codemagic](https://codemagic.io)
2. اربط حساب GitHub
3. اختر المشروع
4. أضف Environment Variables:
   - `EXPO_TOKEN`
   - `APP_STORE_CONNECT_API_KEY`
   - `APP_STORE_CONNECT_KEY_ID`
   - `APP_STORE_CONNECT_ISSUER_ID`

### 3. البناء التلقائي
كل Push على `main` يبدأ بناء iOS تلقائياً!

## 📁 هيكل المشروع

```
store-wallet/
├── App.tsx                     # نقطة الدخول
├── package.json                # التبعيات
├── app.json                    # إعدادات Expo
├── eas.json                    # إعدادات EAS Build
├── codemagic.yaml              # إعدادات CI/CD
├── src/
│   ├── components/             # المكونات
│   ├── screens/                # الشاشات
│   ├── context/                # إدارة الحالة
│   ├── services/               # الخدمات
│   ├── utils/                  # الأدوات
│   ├── data/                   # البيانات الافتراضية
│   └── types/                  # الأنواع
├── backend/                    # Backend
│   └── firebase-functions/
└── ios-shortcuts/              # دليل iOS Shortcuts
```

## ⚠️ ملاحظات

- **iOS**: يتطلب إعداد Shortcuts Automation لاستقبال SMS
- **Android**: يمكن قراءة SMS مباشرة (يتطلب صلاحيات)
- **Push Notifications**: يتطلب حساب Apple Developer ($99/سنة)

## 📄 الترخيص
MIT License
