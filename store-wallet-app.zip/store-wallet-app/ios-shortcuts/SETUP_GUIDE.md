# دليل إعداد iOS Shortcuts لاستقبال SMS تلقائياً

## ⚠️ ملاحظة مهمة
Apple لا تسمح لتطبيقات الطرف الثالث بقراءة SMS مباشرة في iOS. الحل الوحيد هو استخدام **iOS Shortcuts Automation** لإرسال SMS إلى Backend API.

---

## الخطوة 1: الحصول على Device ID
1. افتح تطبيق Store Wallet
2. اذهب إلى Settings → انسخ "معرف الجهاز"
3. ستحتاجه في الخطوة 3

---

## الخطوة 2: إنشاء Automation
1. افتح تطبيق **Shortcuts** على iPhone
2. اذهب إلى تبويب **Automation** في الأسفل
3. اضغط **+** ثم **Create Personal Automation**
4. مرر لأسفل واختر **Message** (الرسائل)
5. في **Sender** اختر **Contains**
6. اكتب اسم المحفظة (مثلاً: `Jawali` أو `Shamil` أو `كاش`)
7. اضغط **Next**

---

## الخطوة 3: إضافة الإجراءات (Actions)

### Action 1: Get Contents of URL
1. اضغط **Add Action**
2. ابحث عن **Get Contents of URL**
3. اضبط الإعدادات:
   - **URL**: `https://your-project.cloudfunctions.net/receiveSms`
     *(استبدل برابط Cloud Function الخاص بك)*
   - **Method**: `POST`
   - **Headers**: اضغط **Add new header**
     - Key: `Content-Type`
     - Value: `application/json`
   - **Request Body**: اختر `JSON`
     - اضغط **Add new field**
     - أنشئ هذه الحقول:

```json
{
  "deviceId": "DEVICE_ID_HERE",
  "sender": "Sender",
  "message": "Message",
  "timestamp": "Current Date"
}
```

### كيفية استخدام المتغيرات في Shortcuts:
- لحقل `sender`: اضغط على الحقل → اختر **Magic Variable** → اختر **Sender** من أعلى
- لحقل `message`: اضغط على الحقل → اختر **Magic Variable** → اختر **Message** من أعلى
- لحقل `timestamp`: اضغط على الحقل → اختر **Current Date** من المتغيرات

---

## الخطوة 4: تعطيل "Ask Before Running"
1. بعد إضافة الإجراءات، اضغط **Next**
2. **مهم جداً**: اضغط على السهم الصغير بجانب **Ask Before Running**
3. اختر **Don't Ask** (لا تسأل)
4. اضغط **Done**

---

## الخطوة 5: تكرار لكل مزود محفظة
كرر الخطوات 2-4 لكل مزود محفظة تستخدمه:
- **Jawali / WeCash / جوالي**
- **Shamil Money / شامل موني**
- **Cash-e / كاش**
- **CAC Bank / كاك بنك**
- **YKB / بنك اليمن والكويت**
- **IBY / البنك الدولي**

---

## 🔧 نصائح مهمة

### 1. التأكد من الاتصال بالإنترنت
- iOS Shortcuts يحتاج إنترنت لإرسال POST request
- إذا لم يكن هناك إنترنت، لن يتم إرسال SMS

### 2. اختبار الـ Automation
1. اطلب من شخص إرسال حوالة لك
2. تحقق من Backend logs
3. تحقق من ظهور الحوالة في التطبيق

### 3. مشاكل شائعة
| المشكلة | الحل |
|---------|------|
| Shortcuts لا يعمل تلقائياً | تأكد من تعطيل "Ask Before Running" |
| API يرجع خطأ 404 | تأكد من صحة رابط Cloud Function |
| الحوالة لا تظهر في التطبيق | تأكد من تطابق deviceId |
| Push Notification لا يصل | تأكد من إعداد Firebase Cloud Messaging |

---

## 📱 بديل: Share Sheet (إذا لم ينجح Automation)
إذا واجهت مشاكل مع Automation:
1. أنشئ Shortcut جديد (ليس Automation)
2. اختر **Share Sheet** كـ Trigger
3. اضبطه ليقبل **Text**
4. أرسل نص SMS عبر Share Sheet للتطبيق
